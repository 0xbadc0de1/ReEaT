
ReEaT - A tool to rebuild a PE's Exports Directory Table.

-> Even if such an entry is missing, the tool will create all necessary artifacts in order
to create such table + add all the specified exports in exports.txt. Currently saving previously
present exports is not supported as well as ordinal only exports. So use with caution.